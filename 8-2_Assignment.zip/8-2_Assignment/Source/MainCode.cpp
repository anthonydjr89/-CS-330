#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <ctime>

const float PI = 3.14159f;

class Brick {
public:
    float x, y, width, height;
    float red, green, blue;

    Brick(float x, float y, float width, float height, float red, float green, float blue)
        : x(x), y(y), width(width), height(height), red(red), green(green), blue(blue) {}

    void draw() const {
        glColor3f(red, green, blue);
        glBegin(GL_QUADS);
        glVertex2f(x - width / 2, y - height / 2);
        glVertex2f(x + width / 2, y - height / 2);
        glVertex2f(x + width / 2, y + height / 2);
        glVertex2f(x - width / 2, y + height / 2);
        glEnd();
    }
};

class Circle {
public:
    float x, y, radius;
    float speedX, speedY;
    float red, green, blue;

    Circle(float x, float y, float radius, float speedX, float speedY, float red, float green, float blue)
        : x(x), y(y), radius(radius), speedX(speedX), speedY(speedY), red(red), green(green), blue(blue) {}

    void move(float deltaTime) {
        x += speedX * deltaTime;
        y += speedY * deltaTime;
        if (x - radius < -1 || x + radius > 1) {
            speedX = -speedX;
        }
        if (y - radius < -1 || y + radius > 1) {
            speedY = -speedY;
        }
    }

    void draw() const {
        glColor3f(red, green, blue);
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        for (int angle = 0; angle < 360; angle += 18) {
            float rad = angle * PI / 180.0f;
            glVertex2f(x + cos(rad) * radius, y + sin(rad) * radius);
        }
        glEnd();
    }
};

class Paddle {
public:
    float x, y, width, height;
    float red, green, blue;

    Paddle(float x, float y, float width, float height, float red, float green, float blue)
        : x(x), y(y), width(width), height(height), red(red), green(green), blue(blue) {}

    void draw() const {
        glColor3f(red, green, blue);
        glBegin(GL_QUADS);
        glVertex2f(x - width / 2, y - height / 2);
        glVertex2f(x + width / 2, y - height / 2);
        glVertex2f(x + width / 2, y + height / 2);
        glVertex2f(x - width / 2, y + height / 2);
        glEnd();
    }

    void moveLeft() {
        if (x - width / 2 > -1) {
            x -= 0.05;
        }
    }

    void moveRight() {
        if (x + width / 2 < 1) {
            x += 0.05;
        }
    }
};

std::vector<Brick> bricks;
std::vector<Circle> circles;
Paddle paddle(0, -0.8, 0.2, 0.05, 1.0, 1.0, 1.0);

void processInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
        paddle.moveLeft();
    }
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
        paddle.moveRight();
    }
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        float x = (float)rand() / RAND_MAX * 2.0f - 1.0f;
        float angle = (float)rand() / RAND_MAX * 360.0f;
        float speed = 0.5f + (float)rand() / RAND_MAX * 0.5f;
        float speedX = cos(angle * PI / 180.0f) * speed;
        float speedY = sin(angle * PI / 180.0f) * speed;
        float red = (float)rand() / RAND_MAX;
        float green = (float)rand() / RAND_MAX;
        float blue = (float)rand() / RAND_MAX;

        circles.push_back(Circle(x, -0.7, 0.05f, speedX, speedY, red, green, blue));
    }
}

int main(void) {
    GLFWwindow* window;
    if (!glfwInit()) return -1;

    window = glfwCreateWindow(640, 480, "Simple Game", NULL, NULL);
    if (!window) {
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // Initialize game objects
    bricks.push_back(Brick(-0.2, 0.8, 0.3, 0.1, 1.0, 0.0, 0.0));  
    bricks.push_back(Brick(0.2, 0.8, 0.3, 0.1, 0.0, 1.0, 0.0));  
    bricks.push_back(Brick(0.4, -0.8, 0.3, 0.1, 1.0, 0.0, 0.0));
    bricks.push_back(Brick(-0.4, -0.8, 0.3, 0.1, 0.0, 1.0, 0.0));

    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        for (auto& brick : bricks) {
            brick.draw();
        }

        for (auto& circle : circles) {
            circle.move(0.096);  
            circle.draw();
        }

        paddle.draw();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
